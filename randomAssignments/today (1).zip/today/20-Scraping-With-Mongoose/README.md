# Scraping with Mongoose

## Instructions

* Open `server.js` and complete the empty routes for accessing all articles, accessing a specific article, and for saving a new article.
