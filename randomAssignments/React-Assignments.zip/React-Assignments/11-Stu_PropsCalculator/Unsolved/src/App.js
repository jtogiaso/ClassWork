import React from "react";
import Calculator from "./components/Calculator";

const App = () => <Calculator />;

export default App;
