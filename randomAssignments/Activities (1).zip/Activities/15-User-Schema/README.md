# User Schema

## Instructions

* Open the `userModel.js` file and complete the User Schema based on the specifications outlined in the file.

* The only file you will need to modify is `userModel.js`.
