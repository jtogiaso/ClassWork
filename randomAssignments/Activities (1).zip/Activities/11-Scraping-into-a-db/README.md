# Scraping into a DB

## Instructions

* Using the tools and techniques you learned so far,
you will scrape a website of your choice, then place the data
in a MongoDB database. Be sure to make the database and collection
before running this exercise.

### Hints

* Consult the assignment files from earlier in the class if you need a refresher on Cheerio.
