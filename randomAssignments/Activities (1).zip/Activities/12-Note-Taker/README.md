# Note Taker

In this activity you will build the backend for a note-taking app.

## Instructions

* Update the [server.js](Unsolved/server.js) file to include the routes specified in the comments.
