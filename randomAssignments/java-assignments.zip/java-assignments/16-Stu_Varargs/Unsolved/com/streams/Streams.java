package com.varargs;

import java.util.Arrays;

import static java.util.Arrays.stream;

class Streams {

  public static void main (String[] args) {
    // Put your tests here.
  }

}
