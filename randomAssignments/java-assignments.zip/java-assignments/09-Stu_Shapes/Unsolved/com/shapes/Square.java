package com.shapes;

import java.lang.Math;

//  Your implementation goes here.
class Square {

    private int sideLength;

}
