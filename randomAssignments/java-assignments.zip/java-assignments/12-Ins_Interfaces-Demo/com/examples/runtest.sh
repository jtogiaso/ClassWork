# Compile all and run test.
javac *.java
java -cp ../../ com.examples.Test
