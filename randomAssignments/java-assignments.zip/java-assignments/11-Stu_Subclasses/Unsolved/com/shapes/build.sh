# Compile all.
javac -cp ../ *.java
