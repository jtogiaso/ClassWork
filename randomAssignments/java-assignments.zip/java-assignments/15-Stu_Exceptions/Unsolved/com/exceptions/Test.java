package com.exceptions;

class Test {

  public static main (String args[]) {
    // Your code here. 
  }

}
