# Arrow Arrays

In this activity we will update the previous arrays example to utilize arrow functions.

## Instructions

* Convert each example to utilize arrow functions.

* All of the code should behave the exact same way as before.
