// Add code to import the spriteLogger function as well as each of the 3 sprites (happyFace, stickFigure, star)

spriteLogger(happyFace);
spriteLogger(stickFigure);
spriteLogger(star);
