import spriteLogger from "./spriteLogger";
import { happyFace, stickFigure, star } from "./sprites";

spriteLogger(happyFace);
spriteLogger(stickFigure);
spriteLogger(star);
