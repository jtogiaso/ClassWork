// Default exports are best used if a module only needs to export one thing,
// or should export something by default if no named import is given

export default [11, 11, 3, 22, 3, 9, 4, 3, 29, 44];
