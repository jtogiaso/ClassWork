import React from "react";
import Alert from "./components/Alert";

const App = () => <Alert type="danger">Invalid user id or password</Alert>;

export default App;
