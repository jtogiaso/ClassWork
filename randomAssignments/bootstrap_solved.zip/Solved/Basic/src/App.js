import React from "react";
import HelloBootstrap from "./components/HelloBootstrap";

const App = () => (
  <div className="container">
    <HelloBootstrap />
  </div>
);

export default App;
