// Default exports are best used if a module only needs to export one thing,
// or should export something by default if no named import is given

export default ["Taco Shells", "Cheddar Jack Cheese", "Sour Cream", "Salsa", "Ground Beef"];
