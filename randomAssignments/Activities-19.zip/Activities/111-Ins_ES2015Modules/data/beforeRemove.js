// Default exports are best used if a module only needs to export one thing,
// or should export something by default if no named import is given

export default [1, 17, 23, 44, -3, 9];
