import React from "react";

const Panel = () => (
  <div className="panel panel-default">
    <div className="panel-heading">
      Non eu sit duis adipisicing esse incididunt ad proident.
    </div>
    <div className="panel-body">
      Aliquip dolore commodo nostrud minim. Cillum do enim non ullamco. Commodo
      magna eu ex mollit sunt amet fugiat. In irure eu enim id ea sit nostrud
      incididunt ad adipisicing.Aliquip dolore commodo nostrud minim. Cillum do
      enim non ullamco. Commodo magna eu ex mollit sunt amet fugiat. In irure eu
      enim id ea sit nostrud incididunt ad adipisicing.
    </div>
  </div>
);

export default Panel;
