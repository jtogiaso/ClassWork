# Obj Destruct

In this activity we will update a JavaScript file to utilize object destructuring.

## Instructions

* Open [obj-destruct.js](Unsolved/obj-destruct.js) and update each function to use object destructuring where indicated in the comments.

### Hints

* Check out the [MDN documentation on destructuring assignment](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Destructuring_assignment)
