import React from "react";
import SearchResultContainer from "./components/SearchResultContainer";

const App = () => <SearchResultContainer />;

export default App;
