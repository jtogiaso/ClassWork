export { default } from "./Detail";
