import React from "react";
import "./Footer.css";

const Footer = () =>
  <footer className="footer">
    <span>Pupster 2017</span>
  </footer>;

export default Footer;
